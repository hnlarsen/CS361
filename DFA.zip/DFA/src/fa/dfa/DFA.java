package fa.dfa;
import fa.State;
import java.util.Set;
import java.util.HashMap;
import java.util.LinkedHashSet;
/**
 *  Class for creating a DFA object containing specified states using a specified
 *  alphabet.
 *  @author Heather N. Larsen, Taylor Roberts
 *  @version    2.0     2018/10/05:19:13
 */
public class DFA implements fa.FAInterface, fa.dfa.DFAInterface {
    /** Map for DFA transitions and corresponding states */
    private final HashMap<HashMap<DFAState, Character>, DFAState> delta;
    /** A set of states within the DFA */
    private final Set<DFAState> Q;
    /** The alphabet for the language of the DFA */
    private final Set sigma;
    /** DFA start state */
    private DFAState q0;
    /** DFA final states */
    private final Set<DFAState> F;
    /** The character representing empty string */
    private final char emptyString;
    /***************************GLOBAL.VARIABES********************************/
    /**
     *  Default constructor.
     */
    public DFA() {
        Q           = new LinkedHashSet<>();
        sigma       = new LinkedHashSet();
        delta       = new HashMap();
        q0          = null;
        F           = new LinkedHashSet<>();
        emptyString = 'e';
    }
    /*********************************DFA**************************************/
    @Override
    public void addStartState(String name) {
        boolean exists = false;
        for(DFAState state : Q) {
            if(state.toString().compareTo(name) == 0) {
                q0 = state;
                exists = true;
            }
        }
        if(!exists) {
            q0 = new DFAState(name);
            Q.add(q0); 
        }
    }
    /*******************************ADD.START.STATE****************************/
    @Override
    public void addState(String name) {
        DFAState newState = new DFAState(name);
        Q.add(newState);
    }
    /********************************ADD.STATE*********************************/
    @Override
    public void addFinalState(String name) {
        DFAState finalState = new DFAState(name);
        boolean exists = false;
        for(DFAState state : Q) {
            if(state.toString().compareTo(name) == 0) {
                state.setFinal();
                F.add(state);
                exists = true;
            }
        }
        if(!exists) {
            finalState.setFinal();
            Q.add(finalState);
            F.add(finalState);
        }
    }
    /******************************ADD.FINAL.STATE*****************************/
    @Override
    public void addTransition(String fromState, char onSymb, String toState) {
        DFAState fState = null, tState = null;
        for(DFAState state : Q) {
            if(state.toString().compareTo(fromState) == 0) {
                fState = state;
            }
            if(state.toString().compareTo(toState) == 0) {
                tState = state;
            }
        }     
        
        HashMap hm = new HashMap<>();
        hm.put(fState, onSymb);
        delta.put(hm, tState);
        sigma.add(onSymb);
    }
    /*******************************ADD.TRANSITION*****************************/
    @Override
    public Set<DFAState> getStates() {
        return Q;
    }
    /*******************************GET.STATES*********************************/
    @Override
    public Set<? extends State> getFinalStates() {
        return F;
    }
    /****************************GET.FINAL.STATES******************************/
    @Override
    public State getStartState() {
        return q0;
    }
    /*****************************GET.START.STATE******************************/
    @Override
    public Set<Character> getABC() {
        return sigma;
    }
    /********************************GET.ABC***********************************/
    @Override
    public boolean accepts(String s) {        
        DFAState curr = q0; //current DFAState | start at q0
        char[] ch     = s.toCharArray();
        
        if((ch[0] == emptyString) && (q0.isFinal()) && (s.length() == 1)) {
            return true;
        }
        
        for(char transition : ch) {
            if(transition == emptyString) { continue; }
            if(!sigma.contains(transition)) {
                return false;
            }
            curr = getToState(curr, transition);
        }
        
        if(curr.isFinal()) { return true;  }
        
        return false;
    }
    /**********************************ACCEPTS*********************************/
    @Override
    public DFAState getToState(DFAState from, char onSymb) {
        HashMap hm = new HashMap<>();
        hm.put(from, onSymb);
        
        DFAState toState = delta.get(hm);
        
        return toState;
    }
    /****************************GET.TO.STATE**********************************/
    @Override
    public String toString() {   
        String sQ = "", sA = "", sF = "";
        
        for(DFAState state : Q) {
            if(sQ.compareTo("") == 0 ) {
                sQ = state.toString();
            }
            else {
                sQ = sQ + " " + state.toString();
            }
        }
        for(Object o : sigma) {
            if(sA.compareTo("") == 0 ) {
                sA = o.toString();
            }
            else {
                sA = sA + " " + o.toString();
                }
        }
        for(DFAState state : F) {
            if(sF.compareTo("") == 0 ) {
                sF = state.toString();
            }
            else {
                sF = sF + " " + state.toString();
                }
        }
        
        String s = "Q = { " + sQ + " }" + System.lineSeparator()
                + "Sigma = { " + sA + " }" + System.lineSeparator()
                + "delta" + System.lineSeparator() 
                + deltaTable()
                + "q0 = " + q0.toString() + System.lineSeparator()
                + "F = { " + sF + " }" + System.lineSeparator();
                
        return s;
    }
    /*****************************TO.STRING************************************/
    /**
     *  Returns a string representation for the delta of the DFA.
     */
    private String deltaTable() {
        String sA = "", query = "";        
        for(Object o : sigma) {
            if(sA.compareTo("") == 0 ) {
                sA = o.toString();
            }
            else {
                sA = sA + "\t" + o.toString();
                }
        }
        for(DFAState state : Q) {
            query = query + "\t" + state + "\t";
            for(Object o : sigma) {
                char[] ch = o.toString().toCharArray();
                DFAState toState = getToState(state, ch[0]);
                query = query + toState.toString() + "\t";
            }
            query = query + System.lineSeparator();
        }
        
        String s = "\t\t" + sA + System.lineSeparator() + query;
        
        return s;
    }
    /******************************DELTA.TABLE*********************************/
}
/***********************************DFA_CLASS**********************************/
