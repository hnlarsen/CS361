package fa.nfa;
/**
 *  Creates a NFAState object to implement in the NFA diagram itself.
 *  @author Heather N. Larsen
 *  @version    1.0     2018/11/10:19:13
 */
public class NFAState extends fa.State {
    /** Determines whether the state is final or not. */
    private boolean finalState;
    /***************************GLOBAL.VARIABLES********************************/
    /**
     *  Default constructor.
     *  @param label name of the state
     */
    public NFAState(String label) {
        this.name       = label;
        this.finalState = false;
    }
    /*****************************DFA.STATE************************************/
    /**
     *  Sets the state as a final state.
     */
    protected void setFinal() {
        this.finalState = true;
    }
    /*****************************SET.FINAL************************************/
    /**
     *  @return true if the state is a final state
     */
    protected boolean isFinal() {
        return finalState;
    }
    /******************************IS.FINAL************************************/
    /**
     * @return the name of the DFAState
     */
    @Override
    public String toString() {
        return this.name;
    }
    /******************************TO.STRING************************************/
}
/********************************NFA_STATE.CLASS*******************************/
