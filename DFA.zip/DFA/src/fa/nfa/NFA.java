package fa.nfa;
import fa.State;
import fa.dfa.DFA;
import fa.dfa.DFAState;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Set;
/**
 *  Class for creating a NFA object containing specified states using a specified
 *  alphabet.
 *  @author Heather N. Larsen
 *  @version    1.0     2018/11/10:19:13
 */
public class NFA implements fa.FAInterface, fa.nfa.NFAInterface {
    /** Map for DFA transitions and corresponding states */
    private final HashMap<HashMap<NFAState, Character>, Set<NFAState>> delta;
    /** A set of states within the DFA */
    private final Set<NFAState> Q;
    /** The alphabet for the language of the DFA */
    private final Set sigma;
    /** DFA start state */
    private NFAState q0;
    /** DFA final states */
    private final Set<NFAState> F;
    /** The character representing empty string */
    private final char emptyString;
    /***************************GLOBAL.VARIABES********************************/
    /**
     * Default constructor.
     */
    public NFA() {
        Q           = new LinkedHashSet<>();
        sigma       = new LinkedHashSet();
        delta       = new HashMap();
        q0          = null;
        F           = new LinkedHashSet<>();
        emptyString = 'e';
    }
    /******************************NFA*****************************************/
    @Override
    public void addStartState(String name) {
        boolean exists = false;
        for(NFAState state : Q) {
            if(state.toString().compareTo(name) == 0) {
                q0 = state;
                exists = true;
            }
        }
        if(!exists) {
            q0 = new NFAState(name);
            Q.add(q0);
        }
    }
    /****************************ADD_START_STATE*******************************/
    @Override
    public void addState(String name) {
        NFAState newState = new NFAState(name);
        Q.add(newState);
    }
    /*********************************ADD_STATE********************************/
    @Override
    public void addFinalState(String name) {
        NFAState finalState = new NFAState(name);
        boolean exists = false;
        for(NFAState state : Q) {
            if(state.toString().compareTo(name) == 0) {
                state.setFinal();
                F.add(state);
                exists = true;
            }
        }
        if(!exists) {
            finalState.setFinal();
            Q.add(finalState);
            F.add(finalState);
        }
    }
    /****************************ADD_FINAL_STATE*******************************/
    @Override
    public void addTransition(String fromState, char onSymb, String toState) {
        NFAState fState = null, tState = null;
        for(NFAState state : Q) {
            if(state.toString().compareTo(fromState) == 0) {
                fState = state;
            }
            if(state.toString().compareTo(toState) == 0) {
                tState = state;
            }
        }
        
        HashMap hm = new HashMap<>();
        hm.put(fState, onSymb);
        if(delta.containsKey(hm)) {
            delta.get(hm).add(tState);
        }
        else {
            Set<NFAState> temp = new LinkedHashSet<>();
            temp.add(tState);
            delta.put(hm, temp);
        }
        sigma.add(onSymb);
    }
    /****************************ADD_TRANSITION********************************/
    @Override
    public Set<? extends State> getStates() {
        return Q;
    }
    /*******************************GET_STATES*********************************/
    @Override
    public Set<? extends State> getFinalStates() {
        return F;
    }
    /****************************GET_FINAL_STATES******************************/
    @Override
    public State getStartState() {
        return q0;
    }
    /****************************GET_START_STATE*******************************/
    @Override
    public Set<Character> getABC() {
        return sigma;
    }
    /*******************************GET_ABC************************************/
    /**
     *  Find the closure for creating a set state.
     *  @param state NFAState being analyzed
     *  @return the set state sequence
     */
    private String findSet(NFAState state) {
        String closure = "";
        for(NFAState s : eClosure(state)) {
            if(closure.length() == 0) {
                closure += s.getName();
            }
            else {
                closure += ", " + s.getName();
            }
        }
        char[] ctemp = closure.toCharArray();
        for(int i = 0; i < ctemp.length; ++i) {
            if(ctemp[i] == ',' || ctemp[i] == ' ') {
                continue;
            }
            else {
                if(i+3 < ctemp.length && ctemp[i] > ctemp[i+3]) {
                    char tmp = ctemp[i];
                    ctemp[i] = ctemp[i+3];
                    ctemp[i+3] = tmp;
                }
            }
        }
        closure = "";
        for(char c : ctemp) {
            closure += c;
        }
        return closure;
    }
    @Override
    public DFA getDFA() {
        DFA dfa = new DFA();
        
        //Find closure set states
        for(NFAState state : Q) {
            String closure = findSet(state);
            
            //Create DFA states from closures
            if(closure.compareTo(q0.getName()) == 0) {
                dfa.addStartState("["+closure+"]");
            }
            else {
                boolean added = false;
                for(NFAState f : F) {
                    if(closure.contains(f.getName())) {
                        dfa.addFinalState("["+closure+"]");
                        added = true;
                    }
                }
                if(!added) {
                    dfa.addState("["+closure+"]");
                }
            }
        }
        //Create transitional links for DFA
        for(Object c : sigma) {
            if(emptyString != (char)c) {
                for(DFAState dfs : dfa.getStates()) {
                    for(NFAState nfs : Q) {
                        String transition = "";
                        if(dfs.getName().contains(nfs.getName())) {
                            if(getToState(nfs, (char)c) == null) { continue; }
                            for(NFAState nsq : getToState(nfs, (char)c)) {
                                if(transition.contains(nsq.getName())) {
                                    continue;
                                }
                                if(transition.compareTo("") == 0) {
                                    transition = nsq.getName();
                                }
                                else {
                                    transition += ", " + nsq.getName();
                                }
                                for(NFAState nsw : eClosure(nfs)) {
                                    if(transition.contains(nsw.getName())) {
                                        continue;
                                    }
                                    if(transition.compareTo("") == 0) {
                                        transition = nsw.getName();
                                    }
                                    else {
                                        transition += ", " + nsw.getName();
                                    }
                                }
                                char[] ctemp = transition.toCharArray();
                                for(int i = 0; i < ctemp.length; ++i) {
                                    if(ctemp[i] == ',' || ctemp[i] == ' ') {
                                        continue;
                                    }
                                    else {
                                        if(i+3 < ctemp.length && ctemp[i] > ctemp[i+3]) {
                                            char tmp = ctemp[i];
                                            ctemp[i] = ctemp[i+3];
                                            ctemp[i+3] = tmp;
                                        }
                                    }
                                }
                                transition = "";
                                for(char k : ctemp) {
                                    transition += k;
                                }
                            }
                        }
                        //Finish the transitional links for the DFA
                        boolean exists = false;
                        for(DFAState toState : dfa.getStates()) {
                            if(toState.getName().compareTo("["+transition+"]") == 0) {
                                exists = true;
                            }
                        }
                        if(exists) {
                            dfa.addTransition(dfs.getName(), (char)c, "["+transition+"]");
                        }
                    }
                }
            }
        }
        
        return dfa;
    }
    /********************************GET_DFA***********************************/
    @Override
    public Set<NFAState> getToState(NFAState from, char onSymb) {
        HashMap hm = new HashMap<>();
        hm.put(from, onSymb);
        
        return delta.get(hm);
    }
    /****************************GET_TO_STATE**********************************/
    @Override
    public Set<NFAState> eClosure(NFAState s) {
        Set<NFAState> states = new LinkedHashSet<>();
        states.add(s);
        
        Set<NFAState> next = getToState(s, emptyString);

        if(next != null) {
            for(NFAState tState : next) {
                Set<NFAState> temp = eClosure(tState);
                for(NFAState q : temp) {
                    states.add(q);
                }
            }
        }
        
        return states;
    }
    /********************************E_CLOSURE*********************************/
}
/*********************************NFA.CLASS************************************/